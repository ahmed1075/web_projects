<?php
session_start();
session_destroy();
?>
          <script>
          window.location.href= 'signin.php';
          </script>
          <?php
?>