      <div
        class="border-right"
        id="sidebar-wrapper"
        style="background-color: #333333;"
      >
        <div class="sidebar-heading">
          <center>
            <img
              src="img/fulfilleedotcom2@2x.png"
              style="width: 150px; margin-top: 10px;"
              class="img-fluid"
            />
          </center>
        </div>
        <div
          class="list-group"
          style="
            background-color: #333333;
            margin-left: 10px;
            margin-right: 10px;
            margin-top: 40px;
          "
        >
                <a
            href="#"
            class="list-group-item"
            style="background-color:#333333;border-color:#333333"
            ></a>
                    <a
                        href="index.php"
            class="list-group-item list-group-item-action ll" style="padding-top:0px"
            
            ><i style="font-size: 22px; margin-right: 20px;padding-top:10px;border-radius:10px" class="fa">&#xf015;</i> Overview</a
          >
         <a
             href="authorization.php"
            class="list-group-item list-group-item-action ll"
            style="
             
            "
            >  <i style="font-size: 22px; margin-right: 20px;margin-left:5px;padding-right:6px" class='far'>&#xf2c1;</i> Store Authorization</a
          >
          <a
            href="marketplace.php"
            class="list-group-item list-group-item-action ll"
            style="
             
            "
            ><i style="font-size: 22px; margin-right: 20px;padding-right:4px" class='fas'>&#xf54e;</i> Marketplace</a
          >
          <a
              href="sourcing.php"
            class="list-group-item list-group-item-action ll"
            style="
        
            "
            ><i style="font-size: 22px; margin-right: 20px;padding-right:8px" class="fas"
              >&#xf075;</i
            >Sourcing</a
          >
          <a
            href="privateproduct.php"
            class="list-group-item list-group-item-action ll"
            style="
             
            "
            ><i style="font-size: 22px; margin-right: 20px;" class="fa">&#xf19c;</i> Private Product List</a
          >
          <a
            href="order.php"
            class="list-group-item list-group-item-action ll"
            style="
           
            "
            ><i style="font-size: 22px; margin-right: 20px;" class="fas"
              >&#xf0e8;</i
            >Orders</a
          >
          <a
            href="#"
            class="list-group-item list-group-item-action ll"
            style="
 
            "
            ><i style="font-size: 22px; margin-right: 20px;" class="fas"
              >&#xf01c;</i
            >Message Center</a
          >
          <a
            href="servicecenter.php"
            class="list-group-item list-group-item-action ll"
            style="
             
            "
            ><i style="font-size: 22px; margin-right: 20px;" class="fas"
              >&#xf05a;</i
            >
            Service Center</a
          >
           <a
            href="logout.php"
            class="list-group-item list-group-item-action ll"
            style="
           margin-top:30%;
            "
            ><i style="font-size: 22px; margin-right: 20px;" class="fas"
              >&#xf2f5;</i
            >
           Log Out</a
          >
                          <a
            href="#"
            class="list-group-item"
            style="background-color:#333333;border-color:#333333"
            ></a>
        </div>
      </div>